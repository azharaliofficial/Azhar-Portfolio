<p
    <?php echo e($attributes->class(['fi-modal-description text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\Users\MASHALLAH\Downloads\azhar-portfolio\azhar-portfolio\backend\vendor\filament\support\resources\views/components/modal/description.blade.php ENDPATH**/ ?>